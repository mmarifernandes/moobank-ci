<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<script src="https://kit.fontawesome.com/84a7caccb6.js" crossorigin="anonymous"></script>
    <title>Error</title>
</head>
<body>
    <i style='font-size:48px; margin-top:20px' class="far fa-frown"></i>
    <h1>Nós não temos a quantidade que você quer comprar disponível no momento.</h1>
</body>
</html>